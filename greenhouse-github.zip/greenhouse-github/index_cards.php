<?php
define('INDEX_CARDS', true);
define('INDEX_ESP', null);
define('INDEX_', null);

include("include/php/h2.php");
$current_light= 100; 
$current_temp = 28; 
//-------------------------
$lastrow=get_last_row();
$row      = explode("||", $lastrow);
                                                                      //бланк данных для карточки

//if($debug){echo("<div class='warning'> cards.php in 8 <pre>"); print_r($row); echo("</pre></div>");}
$card  = array (          "color"   =>    "primary", 
                          "border" =>     "primary",
                          "header"  =>    "#" . trim($row[0]) . "  " . trim($row[1]) ,
                          "title"   =>     "Temperature ". $row[5],
                          "1"       =>      "Light "   . $row[6],
                          "2"       =>      "Humidinty Index "  . $row[11],
                          "3"       =>      "Humidity "  . $row[10],
                          "4"       =>      "Wind "  . $row[7],
                         );


if(array_key_exists('submit', $_REQUEST) ){
$current_light=$_REQUEST['lset'];
$current_temp =$_REQUEST['hset'];
$ip = get_ip_address();
$date = create_date_time();
$str_h = "{H" .$current_temp  . "}";
$str_l = "{L" .$current_light . "}";

$str_command ="\n".  $str_h . $str_l . $delimeter . $ip . $delimeter . $date;
if($debug) echo("index_cards.php 35 \$str_command: $str_command" );
$t=fopen($command_file, "a+"); 
$b=fread($t, 1000);
//if($debug)echo("fread = ". $b);
//fwrite(resource handle, string string, [int length]); fread(resource handle, int length)
$y=fwrite($t, $str_command);  //
//if($debug)echo("Igrek = ". $y);
fclose($t);
}

//if($debug) echo("index_cards " . __line__ . " \$lastrow: $lastrow ");
//------------------------
?>
<!DOCTYPE HTML>
<html>
 <?php 
 include("include/php/head.php");
 ?>
  <body>
  
  <?php include("./sections/navbar1.php");?>
  <style>
.form1 {
	background-color: transparent;
	font-size: xx-large;
	text-align: right;
	float: right;
	padding: 1px;
	margin: 5px;
	border:2px solid #aaa;
	border-radius:4px;
	margin-left:5px;
	padding-left:3px;
}
.radio {
	font-size: 24pt;
}


</style>
     <div class="container">     
	 <div class="row">
	 <div  style="text-align:center; display:inline" >
<?php 

include("./sections/cards.php");
?>


     </div>
      </div>
     
	 <div class="row">
	 <div  style="text-align:center" >

<?php
include("./sections/footer.php");

 ?>
     </div>
	 </div>
  <script src="include/js/carbon.js" type="text/javascript"></script>
<script src="./include/js/jquery.js"></script>
<script src="./include/js/popper.js"></script>
<script src="./include/js/bootstrap.js"></script>
<script src="./include/js/custom.js"></script>
  </body>
</html>
