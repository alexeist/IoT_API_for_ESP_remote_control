<?php
 //functions.php
 //////////////////////////////////////// GLOBALS /////////////////////////////
 $alarm_mess_show =true;
//////////////////////////////////////////
 function decode($f){
return "";                                                 //зарезервировано на будущее
}
//---------------------------
function set_cur_Month(){
$r=0;
}
function get_ip_address() {

    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP',
              'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                    return $ip;
                } else{
                    return("");
                }
            }
        }
    }
}
//--------------------------- Только для чтения --------------------------------
function get_table_body(){
GLOBAL  $debug, $delimeter, $lastrow;
 $ret='';
                                                            //$path_to_bd =
 $data_array_= get_bd();
 if(is_array($data_array_)){
   for($i=1; $i<sizeof($data_array_); $i++){                   // начинаем с первой строки потому что в нулевой - заго
     $temp_head = explode($delimeter, $data_array_[0]);        //берем дату из заголовка файла Базы Данных, каждые сутки в 00:00 этот файл начинается новый.
     $temp_row  =  get_table_row($data_array_[$i]);            // посылаем очередную строку из БД  в гет_тейбл_ров получаем в ответ ХТМЛ строку
     if($i%20 == 1)   $ret .= get_table_head($temp_head[1]);   //через каждые двадцать строк вставляем заголовки столбцов
     $ret .=    $temp_row;
     if(trim($temp_row)) $lastrow=$temp_row;
   }
 }
 return ($ret);
}
//---------------------------
//$bd = "./bd/" $year . "/" .  $month . "/" . $day . ".txt"
function get_card_set($bd=null, $row = 1){
if(null == $bd) $bd= get_bd();
$data_row=explode($delimeter, $bd[$row]);
}
//---------------------------
function create_card_content(){


}
//---------------------------
function set_bd($dt_= null){                                                 // $dt нужная дата в формате DateTime
GLOBAL $path_to_cur_bd, $slash;
$y_      = get_date_($dt_, null, GET_YEAR);
$m_      = get_date_($dt_, null, GET_MONTH);
$d_      = get_date_($dt_, null, GET_DAY);
$path_to_cur_bd = "./bd".$slash . $y_ .$slash . $m_ . $slash . $d_ ."bd.txt";
}
//---------------------------
function get_date_($_a='now', $tz=null,  $_m=GET_DATE_TIME){

$TZ_         = ($tz==null)? new DateTimezone("Europe/Berlin"): new DateTimezone($tz);
 $dt_        = new DateTime($_a, $TZ_);                       // Global class of data in Moscow time
 switch ($_m){

       case (GET_DATE_TIME):
              $ret      = $dt_->format('d/m/Y H:i:s (T)');    break;                                    //Global тексктовая переменная хранит текущее время сессии
       case (GET_DATE):
              $ret      = $dt_->format('d/m/Y');              break;                                // текущая дата (сегодня)
       case (GET_DATE_ZONE):
              $ret      = $dt_->format('d/m/Y (T)');          break;                                // текущая дата (сегодня)
       case (GET_DATE_HEAD_TABLE):
              $ret      = $dt_->format('d/m/Y (Время T)');    break;
       case (GET_TIME_ZONE):
              $ret      = $dt_->format('H:i:s (T)');          break;
       case (GET_TIME):                                                                          // время без часового пояса
              $ret      = $dt_->format('H:i:s');              break;                                          // текущее время (сегодня)
       case (GET_MONTH):
              $ret      = $dt_->format('M');                  break;                                          // текущее время (сегодня)
       case (GET_DAY):
              $ret      = $dt_->format('d');                  break;                                          // текущее время (сегодня)
       case (GET_YEAR):
              $ret      = $dt_->format('Y');                  break;                                          // текущее время (сегодня)
      default:
              $ret      = $dt_->format('d/m/Y H:i:s (T)');     break;
}

return $ret;
}                                                            //
//----------------------------------------------------
function get_table_row($string){                           //   возвращаем HTML ряд таблицы <tr><td></td>...</tr>
 GLOBAL $class, $date_bd, $debug, $delimeter,$_d;
    $class           = $class=="table-primary"?"table-secondary":"table-primary";      // выбираем очередной цвет рядка
    $_d              ++;                                                               //   увеличиваем номер строки для дебаггинга
  $ar                = explode($delimeter, $string);                                   // разрываем строку по делиметеру на аррей
  $re                = "<tr class='" . $class . "'>";                                  // начинаем создавать переменную для  возврата ХТМЛ строки тэга ров
                                                                                        //  if($debug){echo("<br>function: ".__LINE__." \$_d=$_d   \$ar[1] = $ar[1]");}
  if(($ar[0]!="#")&&($ar[0]!="")){                                                            // если первый член аррея - целое число, то это данные, можно работать.
                                                                                        // второй столбец содержит дату и время - их разбиваем на
  $re                .= "<th scope='row' class ='clmn_0'>" .$ar[0] . "</th>";           // explode(string separator, string string, [int limit])
  for($i=1;$i<count($ar);$i++){                                                                  //++ => +1   +=3  => +3       for -это цикл , который повторяется до тех пор пока индекс i  меньше чем каунт- колличество элементов. Как  только меняется значение переменной i (ита). цикл заканчивается и начинается следующая команда.
     $re           .= "<td class='clmn_".$i."'>" .$ar[$i] . "</td>";
 }
    $re .= "</tr>";
  }else{
  $re ='';
  }
   return ($re);
}
//---------------------------
function get_table_row_array( $_string= null, $_delimeter=" || ", $_r=1, $_n=null){                   //$r это колличество параметров в блок данных для карточки
 if(null==$_n) $_n=get_last_row_index();                                                              // использовать эту функцию как можно реже.. будет тормозить
 $_bd=get_bd();
 $_last_row_number  = sizeof($_bd) - 1 ;                                                              //count(ARRAY)
 if (null == $_string) $_string= $_bd[$_n];
  $_ar   = explode($_delimeter, $_string);
 return ($_ar);
}
//----------------------------
function get_last_row_index(){
$f= get_bd();                                                           //  теперь это аррей из строк базы данных текущего месяца
$c=count($f-1);
for($i=$c;$i>0;$i--){
if(trim($f[$i])) return $i;                                         // возвращаем первую зачащую строку с конца Базы Данных
}
return false;
}
//---------------------------
function get_last_row(){
$f= get_bd();
if (is_array($f) ){
for($i=0;$i<count($f) ;$i++){
if(strlen(trim($f[$i]))>0) $ret = $f[$i];                                         // возвращаем первую зачащую строку с конца Базы Данных
}
return $ret;
}else{
echo( 'function.php  ' . __line__ .' ERROR can- not get db');
}
} 
//---------------------------
function get_table_head($_cell){
//$_t = explode(" ", $_cell);
//$d_ = $_t[0]." ". $_t[2];
$table_head  = "<thead><tr style='padding-left:20px'>
                  <th scope='col' style='padding-left:20p;text-align:center'>ТЕСТ</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>" . $_cell . "</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Режим</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Источник<br>Данных</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>IP<br>Адрес</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Внутр. темп.<br>С&deg;</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Освещ.<br> %</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>ВЕТЕР<br>м/с</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Атм. Давл.</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Внешн. Темп.<br>С&deg;</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>Относ. Влжн.<br>%</th>
                  <th scope='col' style='padding-left:20p;text-align:center'>CO2<br> ppm</th>
               </tr></thead>";
 return ($table_head) ;
}
//---------------------------
function get_footer(){
$footer ="<tr class='table-dark'>
                  <th scope='row' colspan='4' style='padding-left:20px'>Zu Haus Robotik Gewachshaus </th>
                  <td colspan='2'>info@c-europe.eu</td>
                  <td colspan='2'>www.c-europe.eu</td>
                  <td colspan='2'>+420 792 455 840</td>
                  <td colspan='2'></td>

    </tr>";
    return ($footer);
}
//---------------------------
function get_bd($cur_year=null, $cur_month=null, $cur_day = null){
  GLOBAL $debug;
  if($cur_year  == null)   $cur_year        = create_date_time('now', 'Europe/Berlin', GET_YEAR);
  if($cur_month == null)   $cur_month       = create_date_time('now', 'Europe/Berlin', GET_MONTH);
  if($cur_day   == null)   $cur_day         = create_date_time('now', 'Europe/Berlin', GET_DAY);
  $t_file="./bd/".$cur_year. "/".$cur_month."/bd".$cur_day.".txt";
  $t=null;
  if(file_exists($t_file)){ 
    $t         =  file($t_file);
  }else{ 
    $alarm_mess_show = true;
    alarm_message("Пожалуйста подождите. Создаем новую Базу Данных");
  }
  return ($t);
}
//---------------------------
function get_cur_month(){

return "";
}
//---------------------------
function get_cur_day(){
return "";
}
//---------------------------
function alarm_error($t){
echo('<div class="alert <!-- alert-dismissible --> alert-warning">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <h4 class="alert-heading">Warning!</h4>
  <p class="mb-0">'.$t.'<a href="#" class="alert-link"></a>.</p>
</div>');

}
//---------------------------
function alarm_message($t){
  global $alarm_mess_show;
  $r='<div class=" alert-info" style="text-align:center"> 
    <h4 class="alert-heading">Warning!</h4>
    <p class="mb-0">'.$t.'.<hr></p>
    </div>';
 if ($alarm_mess_show) {
   echo $r;
   $alarm_mess_show = false;
   }
  
}



//---------------------------------------------------------------

function get_togle_element($label="",$id_switch="customSwitch1", $checked=""){

$t='<div class="form-group">
      <div class="custom-control custom-switch">
        <input type="checkbox" class="custom-control-input" id="' . $id_switch . '" checked="' . $checked .'">
        <label class="custom-control-label" for="customSwitch1">' . $label . '</label>
      </div>
    </div>';
 return $t;
}
//-------------------------------------------------
function get_cards(){
GLOBAL $_REQUEST, $card;
if (array_key_exists('card', $_REQUEST)) $card=get_bd_row_array($_REQUEST['card']);

}

//-------------------------------------------------
function get_bd_row_array($n=null){
GLOBAL $card, $delimeter,$debug;      // $card глобальная переменная, аррей последней записи в БД
if($n==null){return ($card);}             // если не задан номер записи в БД возвращаем последнюю запись, которая хратится в $card
$bd   = get_bd();                        // иначе открываем БД в виде аррея из строк.
if($debug) echo("<hr>"); //var_dump($bd); echo("<hr>");

if( ($n>=0)&&($n<sizeof($bd))) {
$c_   = $bd[$n];                         // выбираем строку с номером $n
$ret= explode($delimeter, $c_);
if(sizeof($ret>0)) {return($ret);}
return (null);

}
alarm_error("Неверно задан номер записи в БД ожидалось положительное число меньшее " . sizeof($bd));
return $card;                              //возвращаем неизменное содержание $card
}
//-------------------------------------------------
function get_month_(){

}
//-------------------------------------------------
function get_day_(){
}
//------------------------------------------------
function set_refresh($t=60,$url="./index.php"){               // по умолчанию рефреш делаем через 60 секунд на страницу ./index.php
 $refresh   = array('<meta http-equiv="refresh" content="',   // строка МЕТА (в хиде ХТМЛ-а) для перезагрузки страницы
                       ';URL=', '">');                        //  второй и третий член строки МЕТА
 $refresh['delay']    = $t;                                   // освежать страницу через... секкунд       МОЖНО МЕНЯТЬЮЮЮЮЮЮЮЮЮ
 $refresh['url']      = $url;                                 // перезагружать страничку...               МОЖНО МЕНЯТЬЮЮЮЮЮЮЮЮЮ
                                                              //   parse_url(string url)


}
function parse_command($_c){
return "";
}
//--------------------------------------------------
function create_date_time($_d='now', $_tz='Europe/Prague' , $_m = GET_DATE_TIME){
 if(null==$_tz) $_tz = "Europe/Berlin";
$dt       = new DateTime($_d, new DateTimezone($_tz));          // Global class of data in Moscow time
if    ($_m==GET_TIME)         { return ($dt->format('H:i:s (T)'));}
elseif($_m==GET_DATE)         { return ($dt->format('d/m/Y'));}
elseif($_m==GET_DAY)          { return ($dt->format('d'));}
elseif($_m==GET_MONTH)        { return ($dt->format('m'));}
elseif($_m==GET_MO)           { return ($dt->format('M'));}
elseif($_m==GET_DAY_NUMBER)   { return ($dt->format('wd'));}                 //
elseif($_m==GET_YEAR)         { return ($dt->format('Y'));}               //
else                          { return ($dt->format('d/m/Y H:i:s (T)'));}
}
//-------------------------------------------------------------
/*
define ("GET_TIME", 0);
define ("GET_DATE", 1);
define ("GET_DAY", 2);
define ("GET_MO", 3);
define ("GET_MONTH_NUMBER", 4);
define ("GET_DAY_NUMBER", 5);
define ("GET_YYYY", 6);
define ("GET_DATE_TIME", 7);
*/
//-------------------------------------------------get_()
function get_($row, $what= GET_DATE_TIME)   {
GLOBAL $path_to_cur_bd;

}
//------------------------------------------------- get_date_from_bd
function get_date_time_from_bd($path_bd=null, $row_number=1, $d_ate=GET_DATE){         // $d_ate = Аррей даты m - код запроса:  0=> вернуть полный формат дата время
  GLOBAL $debug, $delimeter, $Path_to_cur_bd;                                                 //                   1 => вернуть только дату
  // if(null == $m) $m = GET_DATE_TIME;
  if ($path_bd == null) $path_bd = $Path_to_cur_bd;
  if(is_array($d_ate)) {
     if(array_key_exists('year',  $d_ate)) $_year = $d_ate['year'];  else alarm_error("F:" . __LINE__ . "Ошибка. В запросе на БД отсутствует год");   return(null);
     if(array_key_exists('month', $d_ate)) $_month= $d_ate['month']; else alarm_error("F:" . __LINE__ . "Ошибка. В запросе на БД не указан месяц"); return(null);
     if(array_key_exists('day',   $d_ate)) $_day  = $d_ate['day'];   else alarm_error("F:" . __LINE__ . "Ошибка. В запросе на БД нет дня");    return(null);
   }else{
     $_year = "2020";
     $_month = get_($row_number, 'month');
     $_day  = get_($row_number, 'day');
   }

   $path_to_bd=  "./bd/".$_year ."/". $_month ."/";
   $_r=$path_to_bd . $_day .".txt";
  if(file_exists($_r)) {                                                         //                   2 => вернуть только время
   $bd=file($_r);
   $row_ = explode($delimeter, $bd[$row_number]);                     // если не указан номер записи (ряд) БД значит возвращаем первую запись
  if (count($row_)>0){                                               //
      $d_= date_parse($row_[1]);                                    // разрываем полный формат на два элемента аррея 0=> date 1 => time
      if (is_array($d_)){                                          // is_int(mixed var)
        switch ($m){
         case GET_YEAR:  return   $d_['year']; break;
         case GET_MONTH:  return   $d_['month']; break;
         case GET_DATE:   return   $d_['date'];  break;                         // time
         case GET_TIME:   return   $d_['time'];  break;                         // date
         default:  return   $row_[1];  break;            // date time
        }
      } else{alarm_error("F:".__LINE__ . " Ошибка. Не могу разпознать данные в БД как дата-время");}
  }
  return null;
  }
}
//----------------------------------------------------               //
function get_bd_dir($year=null, $month=null, $day=null){
  $dir="./bd";
  if((null == $year) || (null==$month) || (null == $day)) {
    $ar=create_date_time();
    $year  = $ar['year'];
    $month = $ar['month'];
    $day   = $ar['day'];
  }else{
  $ar= array(
             'year' => $year,
             'month'=> $month,
             'day'  => $day
            );
}
return ("./bd/".$year."/".$month);
}
//----------------------------------------------------
function get_command($f){
  $ret = '';
  $comms = file($f);
  array_unshift($comms, "Commands");
   
   for($i=1;$i<count($comms); $i++){
      if(trim($comms[$i])){
	       $ret   =$comms[$i];          // get last command
     }
   }
  
  return $ret;
} 
//----------------------------------------------------
?>
