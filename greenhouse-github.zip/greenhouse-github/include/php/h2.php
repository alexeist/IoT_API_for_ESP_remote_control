<?php
//h2.php

//////////////////////////// GLOBAL CONSTANTS //////////////////////////////////////////////
define ("GET_TIME",             0  );
define ("GET_DATE",             1  );
define ("GET_DAY",              2  );
define ("GET_MONTH",            3  );
define ("GET_MO",               4  );
define ("GET_DAY_NUMBER",       5  );
define ("GET_YEAR",             6  );
define ("GET_DATE_TIME",        7  );
define ("GET_DATE_ZONE",        8  );
define ("GET_TIME_ZONE",        9  );
define ("GET_DATE_HEAD_TABLE", 10 );
//          COMMAND CONSTS   ----------------------
define ("ESP_COMMAND_HEADER", " # || COMMANDS ||   IP || DATESTAMP ||");
/////////////////////////// GLOBAL VARIABLES ////////////////////////////////////////////////
$ver               = " 4.0.1 2024.01.12 ";
$debug             = true;
$title             = "ZuHRo  Terrarium ";
$mode              = '';    // режим  if  TRUE - read only if FALSE - Write new data
$id                = '';   // идентификатор
$test              = '';   //  номер измерения
$light             = '';   // освещенность помещения 
$temp              = '';   // температура 
$temp_ext          = '';   // температура внутри
$humidity          = '';   // влажность 
$humidity_index    = '';   // индекс влажности
$wind              = 0.0;  // ветер
$preasure          = 0;    // давление атмосферное ( внутри и снаружи)
$dinamic_preasure  = "-";   // балл изменения по сравнению с предыдущим от -10 до +10   в декацентах 1/10
$preasure_index    = "-";   // отклонение от среднего за сутки
$month             = "";   //по умолчанию месяц не определяем !!! ВКЛЮЧАЕТ ЗАВЕРШАЮЩИЙ СЛЭШ
$day               = "";   //по умолчанию день не определяем  !!! ВКЛЮЧАЕТ ЗАВЕРШАЮЩИЙ СЛЭШ
$co2               = "";   //  по умолчанию нет данных от СО2 сенсора
$path_to_cur_bd    = "";   // путь к текущей базе данных
//----------------------------
$tz                   = 'Europe/Prague';                                //  по умолчанию Зона часового пояса Москва
$refresh              = array('<meta http-equiv="refresh" content="',   // строка МЕТА (в хиде ХТМЛ-а) для перезагрузки страницы
                               ';URL=',                                 //   второй и
                                '">');                                   //  третий член строки МЕТА
$refresh['delay']  = "360";                                               // время задержки для перезагрузки броузера наблюдателя
$refresh['url']    = "./index.php";                                      // урл перехода по рефрешу
$delimeter         = " || ";                                             // делитеметр  используемый в базе данных
$slash             = "/";                                                // слэш для сборки  путей к файлу
$f                 = '';                                                 // резервная переменная
//$db_url            = "./bd".$slash.$year.$slash.$month.$slash.$day."bd.txt";   // путь к текущей базе данных  от датчиков
$db_register_cmd   = "./bd/command.txt";                                 // регистр комманд для записи в command.php и чтения d index_esp.php
$_d                = 0 ;                                                 //
$lastrow           = '';                                                                         // для дебаггинга (тестирования)

/////////////////////// functions (ГЛОБАЛЬНО ВИДИМЫЕ ПУБЛИЧИНЫЕ)////////////////////////////////
include_once("./include/php/functions.php");
///////////////// вычисляемые переменные ////////////////////////
set_bd();                   // устанавливаем путь к текущей базе данных "./bd/".$year.$slash.$month.$slash.$day.".txt"
//////////////////////////////////////////////////////////  SELECTOR  //////////////////////////////////////////////////////
if(null!==INDEX_CARDS){
//extract($_REQUEST);
$year             = create_date_time(NULL, NULL, GET_YEAR);                                                     // заполняем переменные содержанием рекуеста
$command_file      = "./bd/". $year ."/command.txt";        // база данных комманд. в первой строке - текущая комманда
$date_card         = get_date_('now', $tz, NULL);

$card                 = get_cards();                                    // здесь будет строка текущих карточек
$pars_string          ='?';                                             //начало строки рекуеста
//$refresh['delay']     = 360;                                            // освежать страницу через... секкунд  МОЖНО МЕНЯТЬЮЮЮЮЮЮЮЮЮЮЮЮ
$refresh['url']       = "index_cards.php?par=".$pars_string;                                    // перезагружать страничку...          МОЖНО МЕНЯТЬЮЮЮЮЮЮЮЮЮЮЮЮ
$date_time = get_date_time_from_bd();
$footer = get_footer();
///////////////////////////////////////////////////////////////////////////////////
}elseif(null!==INDEX_ESP){
$refresh[0]='';
$refresh[1]='';
$refresh[2]='';
$refresh['delay']  = "60";
$refresh['url']    = "./index.php";
$date_for_table_head = get_date_('now', $tz, GET_DATE_HEAD_TABLE);
$date_time_for_write = get_date_('now', $tz, GET_TIME);                                    //Global тексктовая переменная хранит текущее время сессии
$client_ip = get_ip_address();                                             //Global ай-пи адрес зпроса
$key = sha1($id);   //
$footer = get_footer();
//00000000000000000
if(array_key_exists('f', $_REQUEST)) $f=decode($_REQUEST['f']);             // параметр рекуеста =  зарезервирован на будущее
$data_array =[];                                      // Global массив, где хранится вся база данных строки записей вместе с делиметероами
include("./sections/table.php");                                            // здесь кранится вся текущая БД в виде таблицы
$dt       =  get_date_('now', 0, "Europe/Prague");                   // текущее время для записи бд в полном формате
$get_month_for_write  = get_month_();                                   // парам.: <ВРЕМЯ>, <формат>, <час. пояс>
$get_day_for_write    = get_date_();                                   // парам.: <ВРЕМЯ>, <формат>, <час. пояс>
$refresh              =  []  ;                            // пустая строка вместо рефреша не делаем перезагрузки странички, потому что она общается с ЕСП
$refresh['delay']     = "";                                            // пустая строка вместо рефреша  задача этой странички - ОДИН раз принять данные от ЕСП и записать в БД
$refresh['url']       = "";                                            // не перезагружать страничку...
//////////////////////////////////////////////////////////////////////////////////
}elseif(null!==INDEX_){
$data_array         = get_bd();                                                  // коды форматов: 0 - дата и время,
$footer             = get_footer();
$togle_element      = get_togle_element();
set_refresh(360);                                                      // воспользуемсся урл по умолчанию
include("./sections/table.php");                                                                       //                1 - только дата
//////////////////////////////////////////////////////////////////////////////////
}else{                                                                  // 2 - только время
alarm_error("h2>".__LINE__ .": Can't understand requestor");
}
$client_ip = get_ip_address();                                         //Global ай-пи адрес зпроса
$date_bd     =  get_date_();
//00000000000000000
if(array_key_exists('f', $_REQUEST)) $f=decode($_REQUEST['f']);        // параметр рекуеста = номер(имя) поддиректория в папке "месяц" зарезервирован на будущее

//$data_array = @file("bd/bd".$f.".txt") ;                             // Global массив, где хранится вся база данных строки записей вместе с делиметероами
                                                                       //if ($debug) {echo("<hr>");/*var_dump($data_array);*/}
                                           // здесь кранится вся текущая БД в виде таблицы
                                                                     //------- конец Глобальных переменных .......

?>
