<?php
// head.php
?>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="./include/css/bootstrap.css" media="screen">
    <link rel="stylesheet" href="./include/css/custom.css">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
      <?php echo($refresh[0] . $refresh['delay'] . $refresh[1] . $refresh['url'] . $refresh[2]) ?>
    <title><?php echo($title)?></title>
  </head>
