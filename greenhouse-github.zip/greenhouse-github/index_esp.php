<?php
$ver_exp  =  "20231125";
define('INDEX_CARDS', null);
define('INDEX_ESP', true);
define('INDEX_', null);
 //ESP_COMMAND_HEADER         // #row            COMMANDS ||   IP || DATESTAMP ||");
        // строка комманд  бывают:    
        // {L+}   Light turn on   for one circle
        // {L=90}  Set Light on/off to 90     (0-dark; 255-bright) 
		// {L-}   Light turn off  for 1 circle 
		// {H=27}  Setn Hitter on off to 27 C
		// {H+}   Hitter turn on for one cirvle
		// {H-}   Hitter turn off for one cirvle
		
include("include/php/h2.php");
$test_url  = "http://zuhro.c-europe.eu/greenhouse/index_cards.php?test=14&id=Sputnik&m=Dom_15&temp=0&light=4&humidity=0&humidity_index=0&temp_ext=0&preasure=0&wind=0.00";
$esp_year  = create_date_time('now', null, GET_YEAR);
$esp_month = create_date_time('now', null, GET_MONTH);
$esp_day   = create_date_time('now', null, GET_DAY);
if(!is_dir("./bd/".$esp_year)){mkdir("./bd/".$esp_year);}
if(!is_dir("./bd/". $esp_year ."/" .$esp_month)){mkdir("./bd/". $esp_year ."/" .$esp_month);}
$esp_bd_file      = "./bd/". $esp_year ."/" .$esp_month."/bd" .$esp_day. ".txt"; //база данных - текстовый файл один на каждый новый день
$esp_command_file = "./bd/". $esp_year ."/command.txt";        // база данных комманд. в первой строке - текущая комманда
$date_ = get_date_('now', $tz, GET_DATE_HEAD_TABLE);
$esp_head_bd     =  " #  ||  Дата: " . $date_ . "        ||      Модуль  || Источник  || IP  || ... параметры согласно локальных заголовков ";
$ip = "192.168.100.121" ;
if(false == file_exists($esp_bd_file)) {
      $f=fopen($esp_bd_file, "a");                         // новый файл.. запишем в него заголовки столбцов
      fwrite($f, $esp_head_bd ."\n");                       //
      fclose($f);                                        // создаем новую базу данных и записываем в нее заголовки столбцов
     }
$_c               = get_command($esp_command_file);                                   // получаем последнюю комманду

/////////////////////////////////////////////////////////////////////////////////
$command=  $_c;//parse_command($_c[count($_c)-1]);                                               // читаем последнюю комманду
/////////////////////////////////////////////////////////////////////////////////       extract(array var_array, [int extract_type], [string prefix])

extract($_REQUEST);
$mode=$m;
//if(array_key_exists("l_ip", $_REQUEST)) $ip=$l_ip;
//if($debug) alarm_message("index_esp:".__LINE__ . " распаковано ". $_ . " переменных из \$_REQUEST" );
//if (array_key_exists('temp', $_REQUEST)) $temp    = $_REQUEST['temp'];
$resp      ='';


if ($mode){                                 //$mode - флаг записывать в БД или нет. или выбор базы данных
 $resp     = $test                . " || " .
             $date_time_for_write . " || " .
             $mode                . " || " .
             $id                  . " || " .
             $client_ip           . " || " .
             $temp                . " || " .
             $light               . " || " .
             $wind                . " || " .
             $preasure            . " || " .
             $temp_ext            . " || " .
             $humidity            . " || " .
             $humidity_index      . "";
////////////////////////////////////////////////


$bd       = fopen($esp_bd_file, "a");
 if($bd){
 fwrite($bd, $resp ."\n");       //  fwrite(resource handle, string string, [int length])
  fclose($bd);
  }else{
  echo("can't open BD");
  }
}

/////////////////////// functions ////////////////////////////////////



?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title><?php echo($title)?></title>
  </head>
  <body>

    <?php 
	 echo($resp);
	 echo("<br>\n Command: ") ;
	 echo($command);
	
	?>
  </body>
</html>
