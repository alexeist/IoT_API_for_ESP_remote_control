<?php
/* This application is full API & Client Interface server for IoT net
You can create your own IoT server in the WWW or Externet with wide net of ESP-clients and publishing results on general browser 
The application is Internet of Things including sketch for  ESP8266 based remote controller
How it work?
The ESP-controller connected to the WWW send the data to the server through it's API (index_esp.php)
The server get the data and automatically save that into text database (db_x.txt) file every day new.
If the current month or year is finished when ESP-controller ask this API, the server automatically creates new path 
./db/currentyear/currentmonth/ and create a new data base file 'db_x.txt' every new day at 00:00:01 (x- is the date)   
The data for current day is open for visiter coming to your http://yoursite.com/ site (index.php).
All other old data is alowed through ftp for owner only.
Author Alexander Eist 2019-2024 aekap ITC, Viber: +420792455840 aekap@c-europe.eu
This app is working here: http://zuhro.c-europe.eu/greenhouse
This app is under MIT license and free for commercial use and edit

*/
define('INDEX_CARDS', null);
define('INDEX_ESP', null);
define('INDEX_', true);

include("include/php/h2.php");
//------------------------
?>
<!DOCTYPE HTML>
<html>
<?php  include("./include/php/head.php")?>
<body>
<?php include("./sections/navbar0.php");?>
   <div class="container">
     <div style="text-align:center">
     <h1><i>Terrarium ZuHRo<?php echo("v. $ver")?></i></h1>
      <p>ZuHRo GH <?php echo($ver)?></p>
     </div>
     <?php  echo($section)?>
      <?php include("./sections/footer.php");?>
   </div>
<script src="include/js/carbon.js" type="text/javascript"></script>
<script src="./include/js/jquery.js"></script>
<script src="./include/js/popper.js"></script>
<script src="./include/js/bootstrap.js"></script>
<script src="./include/js/custom.js"></script>
</body>
</html>
