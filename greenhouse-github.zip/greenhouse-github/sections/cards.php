<?php
//containers_ryad_2.php
 
//echo $dt->format('d/m/Y H:i:s'); 


?>
<div class="card border-primary " style="width: 100%;text-align:center;margin-left:15px">
  <div class="card-header"><?php echo($card["header"])?></div>
  <div class="card-body">
    <h4 class="card-title"><?php echo($card["title"])?></h4>
    <p class="card-text"><?php echo($card["1"])?></p>
	<p class="card-text"><?php echo($card["2"])?></p>
	<p class="card-text"><?php echo($card["3"])?></p>
	<p class="card-text"><?php echo($card["4"])?></p>
	<form action="index_cards.php" id="set_command" method="get" class="form1" style="width: 100%;margin-left:15px">
	      
	      <label>Set Heater
		  <select name="hset" id="hset" size="1" title="Set Temperature on/off or permanent value">
		  <option value="+">Turn ON</option>
		  <option value="-">Turn OFF</option>
          <?php for ($i=18;$i<40; $i++) {
		     $selected='';
		      if($i==$current_temp) {$selected="selected='selected'";}
		   
		  ?>  
			<option value="<?php echo($i)?>" <?php echo($selected); ?>  ><?php echo($i)?> C</option>
          <?php }?>  
           </select>     </label>
		   <br>
		   <label>Set Lighter 
		  <select name="lset" id="lset" size="1" title="Set Light one cirlce on/off or permanent value">
            <option value="+">Turn Light ON</option>
		    <option value="-">Turn Light OFF</option>
		  <?php for ($i=1;$i<256; $i++) { 
		      $selected='';
		      if($i==$current_light) {$selected="selected='selected'";} 
           ?>			  
			<option value="<?php echo($i)?>" <?php echo($selected); ?> ><?php echo($i)?> </option>
          <?php }?>  
           </select>  </label>
		            <br>
		   <input type="submit" name="submit" value="          SET        " />
      
	   
	   </form>
  </div>
</div>
 
       



<?php

/*
echo('<div class="alert alert-dismissible alert-warning">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <h4 class="alert-heading">Warning!</h4>
  <p class="mb-0">
  На данный момент данных для вывода текста на эту страницу нет<br>
  Ждите отправки данных  из теплицы от системы Zuhro GH.
  </a>.</p>
</div>'); 
 
*/

?>
