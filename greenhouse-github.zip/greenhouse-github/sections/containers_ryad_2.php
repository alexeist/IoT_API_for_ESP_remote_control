<?php
//containers_ryad_2.php
 
//echo $dt->format('d/m/Y H:i:s'); 
if(count($_REQUEST)>0){ 
extract($_REQUEST, EXTR_OVERWRITE);

$cartoteka      =  [];
$cartoteka [0]  =  array ("color"   =>    "primary", 
                          "header"  =>    "НОМЕР ПЕРЕДАЧИ ДАННЫХ ИЗМЕРЕНИЯ",
                          "title"   =>     $test,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [1]  =  array ("color"   =>    "secondary", 
                          "header"  =>    "ВРЕМЯ",
                          "title"   =>     $dt->format('d/m/Y H:i:s'),
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [2]  =  array ("color"   =>    "success", 
                          "header"  =>    "ИДЕНТИФИКАТОР",
                          "title"   =>     $id,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [3]  =  array ("color"   =>    "danger", 
                          "header"  =>    "ОБЪЕКТ",
                          "title"   =>     $mode,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [4]  =  array ("color"   =>    "warning", 
                          "header"  =>    "ВНУТРЕННЯЯ TЕМПЕРАТУРА",
                          "title"   =>     $temp,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [5]  =  array ("color"   =>    "info", 
                          "header"  =>    "ОСВЕЩЕННОСТЬ",
                          "title"   =>     $light,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [6]  =  array ("color"   =>    "light", 
                          "header"  =>    "АБСОЛЮТНАЯ ВЛАЖНОСТЬ",
                          "title"   =>     $humidity,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [7]  =  array ("color"   =>    "dark", 
                          "header"  =>    "НАРУЖНАЯ ТЕМПЕРАТУРА",
                          "title"   =>     $temp_ext,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [8]  =  array ("color"   =>    "primari", 
                          "header"  =>    "ВЕТЕР",
                          "title"   =>     $preasure,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [9]  =  array ("color"   =>    "secondary ", 
                          "header"  =>    "ДАВЛЕНИЕ",
                          "title"   =>     $wind,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
$cartoteka [10]  =  array ("color"   =>    "warning", 
                          "header"  =>    "ОТНОСИТЕЛЬНАЯ ВЛАЖНОСТЬ",
                          "title"   =>     $humidity_index,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );                         

/*
$cartoteka [10]  =  array ("color"   =>    "warning", 
                          "header"  =>    "ОТНОСИТЕЛЬНАЯ ВЛАЖНОСТЬ",
                          "title"   =>     $humidity_index,
                          "1"       =>      "",
                          "2"       =>      "",
                          "3"       =>      "",
                          "4"       =>      ""
                         );
                    
 */

                        
///////////////// functions           


?>
<div class="card border-primary mb-3" style="max-width: 20rem;">
  <div class="card-header"><?php echo($cartoteka[0]["header"])?></div>
  <div class="card-body">
    <h4 class="card-title"><?php echo($cartoteka[0]["title"])?></h4>
    <p class="card-text"><?php echo($cartoteka[0]["1|"])?></p>
  </div>
</div>


<?php

 }  else {
echo('<div class="alert alert-dismissible alert-warning">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <h4 class="alert-heading">Warning!</h4>
  <p class="mb-0">
  На данный момент данных для вывода текста на эту страницу нет<br>
  Ждите отправки данных  из теплицы от системы Zuhro GH.
  </a>.</p>
</div>'); 
 }

?>