<?php
////  table.php 
$section ="<div class='container'><div class= 'row'>";
$section .= "<table class='table table-hover tab1'>";
//$section .= $table_head;
$section .= get_table_body();

$section .= $footer;
$section .="</tbody></table></div></div>";
//////////////////functions///////////////////////////////////

?>
