<?php
     //nabbar0.php
?>
<style>
.width100{width:100%!important}
</style>

      <div class="container  fixed-top">


        <div class="widt100">
          <table> <tr>
           <?php echo($table_head)?>

          </tr> </table>

        </div>
      </div>

