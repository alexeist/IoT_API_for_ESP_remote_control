<?php
//custom_select.php


?>

<div class="form-group">
    <select class="custom-select">
      <option selected="">Последняя запись</option>
      <option value="1">Час назад</option>
      <option value="2">Вчера</option>
      <option value="3">Неделю назад</option>
    </select>
  </div>
