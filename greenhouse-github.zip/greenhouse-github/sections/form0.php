<?php
//form0.php
$par=[];
for($i=0;$i<8;$i++){
  $par[$i] = array(
                     'label'       =>  "Параметр "   . strrev($i+1),              // strrev(string string)
                     'type'        => "text"             ,
                     'id'          => "par"         . strrev($i+1) ,
                     'name'        => "par"         . strrev($i+1) ,
                     'size'        => 17 + $i,
                     'placeholder' => "placeholder_" . strrev($i+1) ,
                     'help'        => "help_url_"    . strrev($i+1),
                     'description' => "description"  . strrev($i+1)
    );
}
?>

<form>
  <fieldset>
    <legend>Обозначение</legend>
    <div class="form-group row">
      <label for="staticEmail" class="col-sm-2 col-form-label">Выполняем:  </label>
      <div class="col-lg-6 col-md-8 col-sm-10">
        <input type="text" readonly="readonly" class="form-control-plaintext" id="static_data" value="Программируем ZuhRo GH " style="color:#ccc">
      </div>
    </div>
  <?php for($q=0;$q<count($par);$q++) { ?>
    <div class="form-group">
      <label for="exampleInputEmail1"><?php echo($par[$q]['label'])?></label>
      <input type             = "<?php echo($par[$q]['type'])?>"
             class            = "form-control"
             id               = "<?php echo($par[$q]['id'])?>"
             name             = "<?php echo($par[$q]['name'])?>"
             aria-describedby = "<?php echo($par[$q]['help'])?>"
             placeholder      = "<?php echo($par[$q]['placeholder'])?>">
      <small id="emailHelp" class="form-text text-muted"><?php echo($par[$q]['description'])?></small>
    </div>
    <?php }?>




    <div class="form-group">
      <label for="exampleSelect1">Выбрать значение</label>
      <select class="form-control" id="exampleSelect1">
        <option>1</option>
        <option>2</option>
        <option selected="selected">3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
    <div class="form-group">
      <label for="exampleSelect2">Выбрать несколько значений</label>
      <select multiple="multiple" class="form-control" id="exampleSelect2">
        <option>1</option>
        <option selected="selected">2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </div>
  </fieldset>


    <fieldset class="form-group">
      <legend>Хранить данные на сервере</legend>

      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" class="form-check-input" name="optionsRadios" id="optionsRadios1" value="option1" >
          Выключить автоматическую логистику данных ( В этом случае данные не будут храниться на сервере. Рекомендуется на сервере с ограниченным объемом )
        </label>
      </div>

      <div class="form-check">
      <label class="form-check-label">
          <input type="radio" class="form-check-input" name="optionsRadios" id="optionsRadios2" value="option2" checked="checked">
          Включить автоматическую логистику данных ( Данные будут храниться на сервере. Архив лога каждые сутки увеличивается на 100 КБ )
        </label>
      </div>
    <!--
      <div class="form-check disabled">
      <label class="form-check-label">
          <input type="radio" class="form-check-input" name="optionsRadios" id="optionsRadios3" value="option3" disabled="disabled">
         В данном режиме данная опция не используется
        </label>
      </div>
    -->
    </fieldset>

    <fieldset class="form-group">
      <legend>Checkboxes</legend>
      <div class="form-check">
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox" value="" checked="checked">
          Option one is this and that—be sure to include why it's great
        </label>
      </div>
      <div class="form-check disabled">
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox" value="" disabled="disabled">
          Option two is disabled
        </label>
      </div>
    </fieldset>
    <fieldset class="login">
       <div class="form-group">
      <label for="Login">Пользовательское имя/ email</label>
      <input type="text" class="form-control" id="Password" placeholder="Логин">
      <small id="login" class="form-text text-muted"><a href="repare_password.php?f=name">Забыто имя</a></small>
    </div>

     <div class="form-group">
      <label for="Password">Пароль</label>
      <input type="password" class="form-control" id="Password" placeholder="Password">
      <small id="email" class="form-text text-muted"><a href="repare_password.php?f=psw">Восстановить забытый пароль</a></small>
    </div>
    </fieldset>

    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>
