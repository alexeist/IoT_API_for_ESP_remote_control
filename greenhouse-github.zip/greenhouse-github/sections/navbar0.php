
  <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
   <div class="container">
  <a class="navbar-brand" href="#">TERRARIUM ZuHRo GH <?php echo("v.:" . $ver)?></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="./index.php" title="Главная страница" target="_blank" >Главная <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./index_cards.php" title="Карточки" target="_blank">Setting</a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="#" title="Справки онлайн" target="_blank">Справка</a>
      </li>
    </ul>

    <!--form class="form-inline my-2 my-lg-0">
     <div class="form-group my-2">
    <select class="custom-select mr-sm-2">
      <option selected="">Последняя запись</option>
      <option value="1">Час назад</option>
      <option value="2">Вчера</option>
      <option value="3">Неделю назад</option>
    </select>
  </div>


      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Искать</button>
       <a class="nav-link" href="#" title="Расширенный поиск в Базе данных" target="_blank">Расширенный поиск в БД</a>
    </form-->
  </div>
  </div>
</nav>
